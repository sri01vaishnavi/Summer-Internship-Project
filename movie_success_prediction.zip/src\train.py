from __future__ import annotations

import argparse
import json
from pathlib import Path

import joblib
import pandas as pd

from model import build_pipeline_for_columns, evaluate_binary_classifier



def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Train a movie success prediction model.")
    p.add_argument("--data", required=True, help="Path to movies CSV")
    p.add_argument("--target", default="success", help="Target column name (0/1)")
    p.add_argument(
        "--out",
        default="artifacts/movie_success.joblib",
        help="Output joblib path",
    )
    p.add_argument(
        "--test-size",
        type=float,
        default=0.2,
        help="Fraction for test split",
    )
    p.add_argument(
        "--random-state",
        type=int,
        default=42,
        help="Random seed",
    )
    return p.parse_args()


def main() -> None:
    args = parse_args()

    data_path = Path(args.data)
    if not data_path.exists():
        raise FileNotFoundError(str(data_path))

    df = pd.read_csv(data_path)
    if args.target not in df.columns:
        raise ValueError(f"Target column '{args.target}' not found. Columns: {list(df.columns)}")

    # Basic sanitation
    target = df[args.target]
    if not set(target.dropna().unique()).issubset({0, 1}):
        # Try to coerce common truthy/falsey encodings
        coerced = pd.to_numeric(target, errors="coerce")
        if coerced.isna().all():
            raise ValueError("Target must be binary (0/1).")
        df[args.target] = coerced

    y = df[args.target]
    X = df.drop(columns=[args.target])

    # Decide numeric vs categorical based on dtype
    numeric_cols = [c for c in X.columns if pd.api.types.is_numeric_dtype(X[c])]
    categorical_cols = [c for c in X.columns if c not in numeric_cols]

    # Drop rows where target is missing
    not_null_mask = ~y.isna()
    X = X.loc[not_null_mask]
    y = y.loc[not_null_mask].astype(int)

    # Build pipeline
    model = build_pipeline_for_columns(
        numeric_cols=numeric_cols,
        categorical_cols=categorical_cols,
        random_state=args.random_state,
    )

    # Train/test split via sklearn inside model helpers would be nice, but keep minimal dependencies here
    from sklearn.model_selection import train_test_split

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=args.test_size, random_state=args.random_state, stratify=y
    )

    print(f"Training rows: {len(X_train)} | Test rows: {len(X_test)}")
    print(f"Numeric cols: {len(numeric_cols)} | Categorical cols: {len(categorical_cols)}")

    model.fit(X_train, y_train)

    metrics = evaluate_binary_classifier(model, X_test, y_test)
    print("Evaluation:")
    print(json.dumps(metrics, indent=2))

    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(
        {
            "model": model,
            "numeric_cols": numeric_cols,
            "categorical_cols": categorical_cols,
            "target": args.target,
        },
        out_path,
    )

    print(f"Saved model to: {out_path}")


if __name__ == "__main__":
    main()

