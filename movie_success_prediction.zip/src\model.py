from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.metrics import accuracy_score, roc_auc_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder
from sklearn.ensemble import RandomForestClassifier


@dataclass
class ModelArtifacts:
    model: Any
    feature_names: list[str]


def build_pipeline(random_state: int = 42) -> Pipeline:
    """Builds a preprocessing + model pipeline.

    Preprocessing:
    - numeric: median imputation + passthrough
    - categorical: most_frequent imputation + one-hot

    Model:
    - RandomForestClassifier (baseline, robust for mixed data types)
    """

    # ColumnTransformer expects column lists determined at fit time.
    # We'll use a selector based on dtypes by fitting in train.py where df is known.
    raise RuntimeError(
        "build_pipeline() must be called with explicit column lists via build_pipeline_for_columns()."
    )


def build_pipeline_for_columns(
    numeric_cols: list[str],
    categorical_cols: list[str],
    random_state: int = 42,
) -> Pipeline:
    numeric_transformer = Pipeline(
        steps=[
            ("imputer", SimpleImputer(strategy="median")),
        ]
    )

    categorical_transformer = Pipeline(
        steps=[
            ("imputer", SimpleImputer(strategy="most_frequent")),
            (
                "onehot",
                OneHotEncoder(handle_unknown="ignore", sparse_output=False),
            ),
        ]
    )

    preprocessor = ColumnTransformer(
        transformers=[
            ("num", numeric_transformer, numeric_cols),
            ("cat", categorical_transformer, categorical_cols),
        ],
        remainder="drop",
    )

    clf = RandomForestClassifier(
        n_estimators=400,
        random_state=random_state,
        n_jobs=-1,
        class_weight="balanced",
    )

    model = Pipeline(
        steps=[
            ("preprocess", preprocessor),
            ("clf", clf),
        ]
    )

    return model


def evaluate_binary_classifier(model: Any, X_test, y_test) -> dict[str, float]:
    """Compute accuracy and ROC-AUC when probabilities are available."""

    y_pred = model.predict(X_test)
    metrics: dict[str, float] = {"accuracy": float(accuracy_score(y_test, y_pred))}

    # ROC-AUC if we can get probabilities
    if hasattr(model, "predict_proba"):
        try:
            proba = model.predict_proba(X_test)
            if proba.shape[1] == 2:
                auc = roc_auc_score(y_test, proba[:, 1])
                metrics["roc_auc"] = float(auc)
        except Exception:
            pass

    return metrics


def train_test_split_dataset(X, y, test_size: float = 0.2, random_state: int = 42):
    return train_test_split(X, y, test_size=test_size, random_state=random_state, stratify=y)

