# Movie Success Prediction (Python)

A lightweight end-to-end movie “success” prediction project using **scikit-learn**.

## What it predicts
Given movie metadata/features, the model predicts a **success label** (binary: `0/1`).

## Dataset format
Create a CSV file with:
- A **target column** (default: `success`) containing `0/1` values
- Feature columns (numeric/categorical). Example:
  - `budget`, `runtime`, `vote_average`, `genres`, `language`, `director`, ...

Missing values are handled automatically.

### Minimal example CSV
```csv
success,budget,runtime,genres
1,10000000,120,"Action|Adventure"
0,5000000,95,"Comedy"
```

If you have a different target column name, pass `--target your_column`.

## Project structure
- `src/train.py` - train model + save artifacts
- `src/predict.py` - predict for a CSV of new rows (or interactively)
- `src/model.py` - pipeline + model factory

## Quick start
### 1) Create environment (recommended)
```bash
python -m venv .venv
.venv\Scripts\activate
```

### 2) Install dependencies
```bash
pip install -U pip
pip install scikit-learn pandas joblib
```

### 3) Train
```bash
python src/train.py --data path/to/movies.csv --target success --out artifacts/movie_success.joblib
```

### 4) Evaluate (printed metrics)
Training prints accuracy + ROC-AUC (when possible).

### 5) Predict
```bash
python src/predict.py --model artifacts/movie_success.joblib --input path/to/movies_to_predict.csv --out predictions.csv
```

The output CSV includes a `predicted_success` column.

## Notes / customization
- This is a baseline that works well as a starter.
- For best results, use a dataset with enough rows (typically 1k+).
- You can swap the classifier in `src/model.py`.

