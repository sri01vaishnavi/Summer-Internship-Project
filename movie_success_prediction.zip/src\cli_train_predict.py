from __future__ import annotations

import argparse
import subprocess
import sys


def main() -> None:
    p = argparse.ArgumentParser(description="Convenience wrapper: train or predict")
    sub = p.add_subparsers(dest="cmd", required=True)

    p_train = sub.add_parser("train", help="Train model")
    p_train.add_argument("--data", required=True)
    p_train.add_argument("--target", default="success")
    p_train.add_argument("--out", default="artifacts/movie_success.joblib")
    p_train.add_argument("--test-size", type=float, default=0.2)
    p_train.add_argument("--random-state", type=int, default=42)

    p_pred = sub.add_parser("predict", help="Predict")
    p_pred.add_argument("--model", required=True)
    p_pred.add_argument("--input", required=True)
    p_pred.add_argument("--out", default="predictions.csv")

    args = p.parse_args()

    if args.cmd == "train":
        cmd = [
            sys.executable,
            "src/train.py",
            "--data",
            args.data,
            "--target",
            args.target,
            "--out",
            args.out,
            "--test-size",
            str(args.test_size),
            "--random-state",
            str(args.random_state),
        ]
    else:
        cmd = [
            sys.executable,
            "src/predict.py",
            "--model",
            args.model,
            "--input",
            args.input,
            "--out",
            args.out,
        ]

    subprocess.check_call(cmd)


if __name__ == "__main__":
    main()

