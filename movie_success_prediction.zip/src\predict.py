from __future__ import annotations

import argparse
from pathlib import Path

import joblib
import pandas as pd


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Predict movie success for a CSV of rows")
    p.add_argument("--model", required=True, help="Path to joblib model")
    p.add_argument("--input", required=True, help="Path to input CSV")
    p.add_argument(
        "--out",
        default="predictions.csv",
        help="Output CSV path",
    )
    return p.parse_args()


def main() -> None:
    args = parse_args()

    model_bundle = joblib.load(args.model)
    model = model_bundle["model"]

    df = pd.read_csv(args.input)

    # If the input contains the target column, drop it.
    target = model_bundle.get("target")
    if target and target in df.columns:
        X = df.drop(columns=[target])
    else:
        X = df

    preds = model.predict(X)

    proba = None
    if hasattr(model, "predict_proba"):
        try:
            proba = model.predict_proba(X)[:, 1]
        except Exception:
            proba = None

    df_out = df.copy()
    df_out["predicted_success"] = preds
    if proba is not None:
        df_out["predicted_success_proba"] = proba

    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    df_out.to_csv(out_path, index=False)
    print(f"Wrote predictions to: {out_path}")


if __name__ == "__main__":
    main()

